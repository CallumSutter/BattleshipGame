﻿public enum GameState
{
    /// <summary>
    /// The player is viewing the main menu.

    ViewingMainMenu,

    /// <summary>
    /// The player is viewing the game menu

    ViewingGameMenu,

    /// <summary>
    /// The player is looking at the high scores
 
    ViewingHighScores,

    /// <summary>
    /// The player is altering the game settings

    AlteringSettings,

    /// <summary>
    /// Players are deploying their ships

    Deploying,

    /// <summary>
    /// Players are attempting to locate each others ships

    Discovering,

    /// <summary>
    /// One player has won, showing the victory screen

    EndingGame,

    /// <summary>
    /// The player has quit. Show ending credits and terminate the game

    Quitting
}
